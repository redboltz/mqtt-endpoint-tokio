/**
 * MIT License
 *
 * Copyright (c) 2025 Takatoshi Kondo
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

// Simple MQTT Publisher Example
//
// This is a simplified example that demonstrates basic MQTT endpoint usage.
//
// Usage:
// ```bash
// cargo run --example simple_publisher -- <hostname> <port> <topic> <qos> <payload>
// ```
//
// Example:
// ```bash
// cargo run --example simple_publisher -- localhost 1883 "test/topic" 1 "Hello, MQTT!"
// ```

use std::env;
use std::net::SocketAddr;
use std::process;

use mqtt_endpoint_tokio::mqtt_ep;
use mqtt_endpoint_tokio::mqtt_ep::transport::TcpTransport;
use mqtt_protocol_core::mqtt;
use mqtt_protocol_core::mqtt::result_code::ConnectReturnCode;

type ClientEndpoint = mqtt_ep::Endpoint<mqtt::connection::role::Client>;

#[tokio::main]
async fn main() {
    // Parse command line arguments
    let args: Vec<String> = env::args().collect();

    let (hostname, port, topic, qos, payload) = if args.len() != 6 {
        eprintln!("Usage: {} <hostname> <port> <topic> <qos> <payload>", args[0]);
        eprintln!("Example: {} localhost 1883 \"test/topic\" 1 \"Hello, MQTT!\"", args[0]);
        eprintln!();
        eprintln!("Using default values: 127.0.0.1 1883 t1 1 hello");
        eprintln!();
        (
            "127.0.0.1".to_string(),
            1883u16,
            "t1".to_string(),
            1u8,
            "hello".to_string(),
        )
    } else {
        let hostname = args[1].clone();
        let port: u16 = args[2].parse().unwrap_or_else(|_| {
            eprintln!("Error: Invalid port number '{}'", args[2]);
            process::exit(1);
        });
        let topic = args[3].clone();
        let qos: u8 = args[4].parse().unwrap_or_else(|_| {
            eprintln!("Error: Invalid QoS level '{}'. Must be 0, 1, or 2", args[4]);
            process::exit(1);
        });
        let payload = args[5].clone();
        (hostname, port, topic, qos, payload)
    };

    let qos_level = mqtt::packet::Qos::try_from(qos).expect("Error: Invalid QoS level '{qos}'. Must be 0, 1, or 2");

    println!("Simple MQTT Publisher");
    println!("Broker: {}:{}", hostname, port);
    println!("Topic: {}", topic);
    println!("QoS: {:?}", qos_level);
    println!("Payload: {}", payload);

    // Create socket address
    let addr = format!("{}:{}", hostname, port);
    let socket_addr: SocketAddr = addr.parse().unwrap_or_else(|_| {
        eprintln!("Error: Invalid hostname or port");
        process::exit(1);
    });

    // Create MQTT endpoint
    let endpoint: ClientEndpoint = mqtt_ep::Endpoint::new(mqtt::Version::V3_1_1);

    // Create TCP transport
    let transport = TcpTransport::new(socket_addr);

    // Connect to the broker (transport layer)
    println!("Connecting to broker...");
    if let Err(e) = endpoint.connect(transport).await {
        eprintln!("Error: Failed to connect to broker: {:?}", e);
        process::exit(1);
    }
    println!("Transport connected successfully!");

    // Send MQTT CONNECT packet
    println!("Sending CONNECT packet...");
    let connect_packet = mqtt::packet::v3_1_1::Connect::builder()
        .client_id("rust_publisher")
        .unwrap()
        .keep_alive(60)
        .clean_session(true)
        .build()
        .unwrap();

    if let Err(e) = endpoint.send(connect_packet).await {
        eprintln!("Error: Failed to send CONNECT packet: {:?}", e);
        process::exit(1);
    }

    // Wait for CONNACK
    println!("Waiting for CONNACK...");
    match endpoint.recv().await {
        Ok(packet) => {
            match packet {
                mqtt::packet::Packet::V3_1_1Connack(connack) => {
                    if connack.return_code() != ConnectReturnCode::Accepted {
                        eprintln!("Error: Connection refused: {:?}", connack.return_code());
                        process::exit(1);
                    }
                    println!("MQTT connection accepted by broker");
                }
                _ => {
                    eprintln!("Error: Expected CONNACK, received: {:?}", packet.packet_type());
                    process::exit(1);
                }
            }
        }
        Err(e) => {
            eprintln!("Error: Failed to receive CONNACK: {:?}", e);
            process::exit(1);
        }
    }

    // Create PUBLISH packet
    let publish_builder = mqtt::packet::v3_1_1::Publish::builder()
        .topic_name(topic)
        .unwrap()
        .qos(qos_level)
        .retain(false)
        .payload(payload.as_bytes());

    // Add packet ID for QoS 1 and 211
    let publish_packet = if qos_level != mqtt::packet::Qos::AtMostOnce {
        let packet_id = match endpoint.acquire_packet_id().await {
            Ok(id) => id,
            Err(e) => {
                eprintln!("Error: Failed to acquire packet ID: {:?}", e);
                process::exit(1);
            }
        };
        publish_builder.packet_id(packet_id).build().unwrap()
    } else {
        publish_builder.build().unwrap()
    };

    println!("Publishing message... {}", publish_packet);
    if let Err(e) = endpoint.send(publish_packet.clone()).await {
        eprintln!("Error: Failed to send PUBLISH packet: {:?}", e);
        process::exit(1);
    }

    // Handle QoS acknowledgements
    match qos_level {
        mqtt::packet::Qos::AtMostOnce => {
            println!("Message published successfully (QoS 0 - fire and forget)");
        }
        mqtt::packet::Qos::AtLeastOnce => {
            // Wait for PUBACK
            println!("Waiting for PUBACK...");
            match endpoint.recv().await {
                Ok(packet) => {
                    match packet {
                        mqtt::packet::Packet::V3_1_1Puback(puback) => {
                            println!("Message published successfully (QoS 1 - received PUBACK for packet ID {})", puback.packet_id());
                        }
                        _ => {
                            eprintln!("Error: Expected PUBACK, received: {:?}", packet.packet_type());
                            process::exit(1);
                        }
                    }
                }
                Err(e) => {
                    eprintln!("Error: Failed to receive PUBACK: {:?}", e);
                    process::exit(1);
                }
            }
        }
        mqtt::packet::Qos::ExactlyOnce => {
            // Wait for PUBREC
            println!("Waiting for PUBREC...");
            match endpoint.recv().await {
                Ok(packet) => {
                    match packet {
                        mqtt::packet::Packet::V3_1_1Pubrec(pubrec) => {
                            println!("Received PUBREC for packet ID {}", pubrec.packet_id());

                            // Send PUBREL
                            let pubrel = mqtt::packet::v3_1_1::Pubrel::builder()
                                .packet_id(pubrec.packet_id())
                                .build()
                                .unwrap();
                            if let Err(e) = endpoint.send(pubrel).await {
                                eprintln!("Error: Failed to send PUBREL: {:?}", e);
                                process::exit(1);
                            }

                            // Wait for PUBCOMP
                            println!("Waiting for PUBCOMP...");
                            match endpoint.recv().await {
                                Ok(packet) => {
                                    match packet {
                                        mqtt::packet::Packet::V3_1_1Pubcomp(pubcomp) => {
                                            println!("Message published successfully (QoS 2 - received PUBCOMP for packet ID {})", pubcomp.packet_id());
                                        }
                                        _ => {
                                            eprintln!("Error: Expected PUBCOMP, received: {:?}", packet.packet_type());
                                            process::exit(1);
                                        }
                                    }
                                }
                                Err(e) => {
                                    eprintln!("Error: Failed to receive PUBCOMP: {:?}", e);
                                    process::exit(1);
                                }
                            }
                        }
                        _ => {
                            eprintln!("Error: Expected PUBREC, received: {:?}", packet.packet_type());
                            process::exit(1);
                        }
                    }
                }
                Err(e) => {
                    eprintln!("Error: Failed to receive PUBREC: {:?}", e);
                    process::exit(1);
                }
            }
        }
    }

    // Send DISCONNECT packet (good practice)
    println!("Sending DISCONNECT packet...");
    let disconnect_packet = mqtt::packet::v3_1_1::Disconnect::new();
    if let Err(e) = endpoint.send(disconnect_packet).await {
        eprintln!("Warning: Failed to send DISCONNECT packet: {:?}", e);
    }

    // Close connection gracefully
    if let Err(e) = endpoint.close().await {
        eprintln!("Warning: Failed to close connection properly: {:?}", e);
    }

    println!("Publisher finished successfully.");
}