/**
 * MIT License
 *
 * Copyright (c) 2025 Takatoshi Kondo
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
use std::future;
use std::marker::PhantomData;
use std::time::Duration;
use std::collections::HashSet;

use tokio::sync::{mpsc, oneshot};
use tokio::time::sleep;

use tracing::{error, info, trace};

use mqtt_protocol_core::mqtt;
use mqtt_protocol_core::mqtt::prelude::*;

use crate::mqtt_ep::connection_option::GenericConnectionOption;
use crate::mqtt_ep::packet_filter::PacketFilter;
use crate::mqtt_ep::request_response::{ConnectionError, RequestResponse};

/// Configuration for MQTT endpoint (settable only at initialization time)
#[derive(Debug, Clone)]
pub struct GenericEndpointConfig<PacketIdType>
where
    PacketIdType: mqtt::types::IsPacketId + Send + Sync,
{
    _marker: PhantomData<PacketIdType>,
}

impl<PacketIdType> Default for GenericEndpointConfig<PacketIdType>
where
    PacketIdType: mqtt::types::IsPacketId + Send + Sync,
{
    fn default() -> Self {
        Self {
            _marker: PhantomData,
        }
    }
}

pub type EndpointConfig = GenericEndpointConfig<u16>;

/// Builder for creating GenericEndpoint with custom configuration
pub struct GenericEndpointBuilder<Role, PacketIdType>
where
    Role: mqtt::role::RoleType + Send + Sync,
    PacketIdType: mqtt::types::IsPacketId + Send + Sync,
{
    version: mqtt::Version,
    config: GenericEndpointConfig<PacketIdType>,
    _marker: PhantomData<(Role, PacketIdType)>,
}

impl<Role, PacketIdType> GenericEndpointBuilder<Role, PacketIdType>
where
    Role: mqtt::role::RoleType + Send + Sync,
    PacketIdType: mqtt::types::IsPacketId + Send + Sync,
    <PacketIdType as mqtt::types::IsPacketId>::Buffer: Send,
{
    /// Create a new builder with the specified MQTT version
    pub fn new(version: mqtt::Version) -> Self {
        Self {
            version,
            config: GenericEndpointConfig::<PacketIdType>::default(),
            _marker: PhantomData,
        }
    }

    /// Build the endpoint (initially in disconnected state)
    pub fn build(self) -> GenericEndpoint<Role, PacketIdType> {
        GenericEndpoint::new_with_config(self.version, self.config)
    }
}

pub struct GenericEndpoint<Role, PacketIdType>
where
    Role: mqtt::role::RoleType + Send + Sync,
    PacketIdType: mqtt::types::IsPacketId + Send + Sync,
{
    #[allow(dead_code)] // Used in constructor and may be used for version checking in future
    version: mqtt::Version,
    config: GenericEndpointConfig<PacketIdType>,
    tx_send: mpsc::UnboundedSender<RequestResponse<PacketIdType>>,
    #[allow(dead_code)] // May be used for cleanup in future Drop implementation
    event_loop_handle: tokio::task::JoinHandle<()>,
    _marker: PhantomData<Role>,
}

impl<Role, PacketIdType> GenericEndpoint<Role, PacketIdType>
where
    Role: mqtt::role::RoleType + Send + Sync,
    PacketIdType: mqtt::types::IsPacketId + Send + Sync,
    <PacketIdType as mqtt::types::IsPacketId>::Buffer: Send,
{
    /// Create a new builder for configuring the endpoint
    pub fn builder(version: mqtt::Version) -> GenericEndpointBuilder<Role, PacketIdType> {
        GenericEndpointBuilder::new(version)
    }

    /// Create a new endpoint with default configuration (initially disconnected)
    pub fn new(version: mqtt::Version) -> Self {
        Self::new_with_config(version, GenericEndpointConfig::<PacketIdType>::default())
    }

    /// Create a new endpoint with custom configuration (initially disconnected)
    pub fn new_with_config(version: mqtt::Version, config: GenericEndpointConfig<PacketIdType>) -> Self {
        let connection = mqtt::GenericConnection::new(version);
        let (tx_send, rx_send) = mpsc::unbounded_channel();

        // Start event loop immediately
        let event_loop_handle = tokio::spawn(Self::event_loop(connection, rx_send));

        Self {
            version,
            config,
            tx_send,
            event_loop_handle,
            _marker: PhantomData,
        }
    }

    async fn process_events<S>(
        connection: &mut mqtt::GenericConnection<Role, PacketIdType>,
        transport: &mut S,
        pingreq_send_timer: &mut Option<tokio::task::JoinHandle<()>>,
        pingreq_recv_timer: &mut Option<tokio::task::JoinHandle<()>>,
        pingresp_recv_timer: &mut Option<tokio::task::JoinHandle<()>>,
        timer_tx: &mpsc::UnboundedSender<TimerKind>,
        pending_packet_id_requests: &mut Vec<oneshot::Sender<Result<PacketIdType, ConnectionError>>>,
        events: Vec<GenericEvent<PacketIdType>>,
    ) -> Result<(), ConnectionError>
    where
        S: crate::mqtt_ep::transport::TransportOps,
    {
        let mut first_error: Option<ConnectionError> = None;
        for event in events {
            match event {
                GenericEvent::NotifyPacketIdReleased(_packet_id) => {
                    Self::process_packet_id_waiting_queue(connection, pending_packet_id_requests);
                }
                GenericEvent::RequestSendPacket {
                    packet,
                    release_packet_id_if_send_error,
                } => {
                    let buffers = packet.to_buffers();
                    let send_result = transport.send(&buffers).await;

                    match send_result {
                        Ok(_) => {
                            // Successfully sent - TransportOps::send handles flushing internally
                        }
                        Err(_) => {
                            if let Some(packet_id) = release_packet_id_if_send_error {
                                let release_events = connection.release_packet_id(packet_id);
                                let mut empty_queue = Vec::new();
                                let _ = Box::pin(Self::process_events(
                                    connection,
                                    transport,
                                    pingreq_send_timer,
                                    pingreq_recv_timer,
                                    pingresp_recv_timer,
                                    timer_tx,
                                    &mut empty_queue,
                                    release_events,
                                ))
                                .await;
                                // Note: We ignore MQTT errors during packet ID release
                                // as they are secondary to the send failure
                            }
                        }
                    }
                }
                GenericEvent::RequestTimerReset { kind, duration_ms } => match kind {
                    TimerKind::PingreqSend => {
                        if let Some(handle) = pingreq_send_timer.take() {
                            handle.abort();
                        }
                        let timer_tx_clone = timer_tx.clone();
                        let handle = tokio::spawn(async move {
                            sleep(Duration::from_millis(duration_ms)).await;
                            let _ = timer_tx_clone.send(kind);
                        });
                        *pingreq_send_timer = Some(handle);
                    }
                    TimerKind::PingreqRecv => {
                        if let Some(handle) = pingreq_recv_timer.take() {
                            handle.abort();
                        }
                        let timer_tx_clone = timer_tx.clone();
                        let handle = tokio::spawn(async move {
                            sleep(Duration::from_millis(duration_ms)).await;
                            let _ = timer_tx_clone.send(kind);
                        });
                        *pingreq_recv_timer = Some(handle);
                    }
                    TimerKind::PingrespRecv => {
                        if let Some(handle) = pingresp_recv_timer.take() {
                            handle.abort();
                        }
                        let timer_tx_clone = timer_tx.clone();
                        let handle = tokio::spawn(async move {
                            sleep(Duration::from_millis(duration_ms)).await;
                            let _ = timer_tx_clone.send(kind);
                        });
                        *pingresp_recv_timer = Some(handle);
                    }
                },
                GenericEvent::RequestTimerCancel(kind) => match kind {
                    TimerKind::PingreqSend => {
                        if let Some(handle) = pingreq_send_timer.take() {
                            handle.abort();
                        }
                    }
                    TimerKind::PingreqRecv => {
                        if let Some(handle) = pingreq_recv_timer.take() {
                            handle.abort();
                        }
                    }
                    TimerKind::PingrespRecv => {
                        if let Some(handle) = pingresp_recv_timer.take() {
                            handle.abort();
                        }
                    }
                },
                GenericEvent::RequestClose => {
                    let _ = crate::mqtt_ep::transport::TransportOps::shutdown(
                        transport,
                        Duration::from_secs(5),
                    )
                    .await;
                }
                GenericEvent::NotifyError(error) => {
                    // Store the first MQTT protocol error for API response
                    // Only store the first error if none has been stored yet
                    if first_error.is_none() {
                        first_error = Some(ConnectionError::from(error));
                    }
                    // Also log for debugging purposes
                    eprintln!("MQTT protocol error: {:?}", error);
                }
                GenericEvent::NotifyPacketReceived(_packet) => {
                    // This should not happen in process_events
                    // NotifyPacketReceived is handled separately in RequestResponse::Recv
                }
            }
        }

        // Return the first error if any occurred, otherwise Ok
        if let Some(error) = first_error {
            Err(error)
        } else {
            Ok(())
        }
    }

    /// Process the packet ID waiting queue when a packet ID is released
    fn process_packet_id_waiting_queue(
        connection: &mut mqtt::GenericConnection<Role, PacketIdType>,
        pending_requests: &mut Vec<oneshot::Sender<Result<PacketIdType, ConnectionError>>>,
    ) {
        // Process requests from the front (index 0) to maintain FIFO order
        while !pending_requests.is_empty() {
            // Note: acquire_packet_id() returns Result<PacketIdType, MqttError>, no events
            match connection.acquire_packet_id() {
                Ok(packet_id) => {
                    // Successfully acquired packet ID, remove and send to the first waiting requester
                    let response_tx = pending_requests.remove(0);
                    let _ = response_tx.send(Ok(packet_id));
                }
                Err(mqtt_error) => {
                    // Failed to acquire packet ID - convert MqttError to ConnectionError
                    let connection_error = ConnectionError::from(mqtt_error);
                    // Send error to the first waiting requester and stop processing to maintain order
                    if !pending_requests.is_empty() {
                        // Remove the first pending request and send the error
                        let response_tx = pending_requests.remove(0);
                        let _ = response_tx.send(Err(connection_error));
                    }
                    break;
                }
            }
        }
    }

    /// Send MQTT packet with compile-time type safety
    ///
    /// This method accepts any packet type that implements `Sendable<Role, PacketIdType>`
    /// for compile-time verification, or `GenericPacket<PacketIdType>` for dynamic cases.
    /// All packets are converted to GenericPacket internally via the Into trait.
    pub async fn send<T>(&self, packet: T) -> Result<(), ConnectionError>
    where
        T: Into<mqtt::packet::GenericPacket<PacketIdType>> + Sendable<Role, PacketIdType> + Send + 'static,
    {
        let tx_send = self.get_tx_send();
        let (response_tx, response_rx) = oneshot::channel();

        tx_send
            .send(RequestResponse::Send {
                packet: Box::<mqtt::packet::GenericPacket<PacketIdType>>::new(packet.into()),
                response_tx,
            })
            .map_err(|_| ConnectionError::ChannelClosed)?;

        response_rx.await.map_err(|_| ConnectionError::ChannelClosed)?
    }

    /// Receive any MQTT packet
    pub async fn recv(&self) -> Result<mqtt::packet::GenericPacket<PacketIdType>, ConnectionError> {
        self.recv_filtered(PacketFilter::Any).await
    }

    /// Receive MQTT packet matching the specified filter
    pub async fn recv_filtered(
        &self,
        filter: PacketFilter,
    ) -> Result<mqtt::packet::GenericPacket<PacketIdType>, ConnectionError> {
        let tx_send = self.get_tx_send();
        let (response_tx, response_rx) = oneshot::channel();

        tx_send
            .send(RequestResponse::Recv {
                filter,
                response_tx,
            })
            .map_err(|_| ConnectionError::ChannelClosed)?;

        response_rx.await.map_err(|_| ConnectionError::ChannelClosed)?
    }

    /// Acquire a unique packet ID
    pub async fn acquire_packet_id(&self) -> Result<PacketIdType, ConnectionError> {
        let tx_send = self.get_tx_send();
        let (response_tx, response_rx) = oneshot::channel();

        tx_send
            .send(RequestResponse::AcquirePacketId { response_tx })
            .map_err(|_| ConnectionError::ChannelClosed)?;

        response_rx.await.map_err(|_| ConnectionError::ChannelClosed)?
    }

    /// Acquire a unique packet ID, waiting until one becomes available
    ///
    /// Unlike acquire_packet_id(), this method will not return an error
    /// if all packet IDs are currently in use. Instead, it will wait until
    /// a packet ID is released and becomes available.
    pub async fn acquire_packet_id_when_available(&self) -> Result<PacketIdType, ConnectionError> {
        let tx_send = self.get_tx_send();
        let (response_tx, response_rx) = oneshot::channel();

        tx_send
            .send(RequestResponse::AcquirePacketIdWhenAvailable { response_tx })
            .map_err(|_| ConnectionError::ChannelClosed)?;

        response_rx.await.map_err(|_| ConnectionError::ChannelClosed)?
    }

    /// Register a packet ID as in use
    pub async fn register_packet_id(&self, packet_id: PacketIdType) -> Result<(), ConnectionError> {
        let tx_send = self.get_tx_send();
        let (response_tx, response_rx) = oneshot::channel();

        tx_send
            .send(RequestResponse::RegisterPacketId {
                packet_id,
                response_tx,
            })
            .map_err(|_| ConnectionError::ChannelClosed)?;

        response_rx.await.map_err(|_| ConnectionError::ChannelClosed)?
    }

    /// Release a packet ID
    pub async fn release_packet_id(&self, packet_id: PacketIdType) -> Result<(), ConnectionError> {
        let tx_send = self.get_tx_send();
        let (response_tx, response_rx) = oneshot::channel();

        tx_send
            .send(RequestResponse::ReleasePacketId {
                packet_id,
                response_tx,
            })
            .map_err(|_| ConnectionError::ChannelClosed)?;

        response_rx.await.map_err(|_| ConnectionError::ChannelClosed)?
    }

    /// Get all stored packets from the connection store
    ///
    /// This method retrieves all currently stored packets from the connection.
    /// This is typically used for session persistence to save in-flight QoS 1 and QoS 2 packets
    /// before closing the connection, so they can be restored later with restore_packets().
    pub async fn get_stored_packets(
        &self,
    ) -> Result<Vec<mqtt::packet::GenericStorePacket<PacketIdType>>, ConnectionError> {
        let tx_send = self.get_tx_send();
        let (response_tx, response_rx) = oneshot::channel();

        tx_send
            .send(RequestResponse::GetStoredPackets { response_tx })
            .map_err(|_| ConnectionError::ChannelClosed)?;

        response_rx.await.map_err(|_| ConnectionError::ChannelClosed)?
    }

    /// Set offline publish state
    ///
    /// This method controls whether the endpoint should handle publish packets when offline.
    /// When set to true, publish packets may be queued or handled differently when the transport is disconnected.
    pub async fn set_offline_publish(&self, offline_publish: bool) -> Result<(), ConnectionError> {
        let tx_send = self.get_tx_send();
        let (response_tx, response_rx) = oneshot::channel();

        tx_send
            .send(RequestResponse::SetOfflinePublish {
                offline_publish,
                response_tx,
            })
            .map_err(|_| ConnectionError::ChannelClosed)?;

        response_rx.await.map_err(|_| ConnectionError::ChannelClosed)?
    }

    /// Get QoS 2 publish handled packet IDs
    ///
    /// This method retrieves all packet IDs for QoS 2 PUBLISH packets that have been handled.
    /// This is typically used for session persistence to save which QoS 2 publishes have been processed
    /// before closing the connection, so duplicate handling can be avoided when restoring the session.
    pub async fn get_qos2_publish_handled_pids(&self) -> Result<HashSet<PacketIdType>, ConnectionError> {
        let tx_send = self.get_tx_send();
        let (response_tx, response_rx) = oneshot::channel();

        tx_send
            .send(RequestResponse::GetQos2PublishHandled { response_tx })
            .map_err(|_| ConnectionError::ChannelClosed)?;

        response_rx.await.map_err(|_| ConnectionError::ChannelClosed)?
    }

    /// Get receive maximum vacancy for send
    ///
    /// This method returns the number of additional QoS 1 and QoS 2 packets that can be sent
    /// before reaching the receive maximum limit imposed by the peer. This helps implement
    /// flow control to avoid exceeding the peer's processing capacity.
    pub async fn get_receive_maximum_vacancy_for_send(&self) -> Result<Option<u16>, ConnectionError> {
        let tx_send = self.get_tx_send();
        let (response_tx, response_rx) = oneshot::channel();

        tx_send
            .send(RequestResponse::GetReceiveMaximumVacancyForSend { response_tx })
            .map_err(|_| ConnectionError::ChannelClosed)?;

        response_rx.await.map_err(|_| ConnectionError::ChannelClosed)?
    }

    /// Get protocol version
    ///
    /// This method returns the MQTT protocol version currently being used by the connection.
    /// This is a memo (cached) value that reflects the protocol version negotiated during connection establishment.
    pub async fn get_protocol_version(&self) -> Result<mqtt::Version, ConnectionError> {
        let tx_send = self.get_tx_send();
        let (response_tx, response_rx) = oneshot::channel();

        tx_send
            .send(RequestResponse::GetProtocolVersion { response_tx })
            .map_err(|_| ConnectionError::ChannelClosed)?;

        response_rx.await.map_err(|_| ConnectionError::ChannelClosed)?
    }

    /// Check if a publish packet is currently being processed
    ///
    /// This method checks whether a QoS 1 or QoS 2 PUBLISH packet with the given packet ID
    /// is currently being processed. This can be used to determine if a packet ID is in use
    /// for publish operations before attempting to use it for other packet types.
    pub async fn is_publish_processing(&self, packet_id: PacketIdType) -> Result<bool, ConnectionError> {
        let tx_send = self.get_tx_send();
        let (response_tx, response_rx) = oneshot::channel();

        tx_send
            .send(RequestResponse::IsPublishProcessing {
                packet_id,
                response_tx,
            })
            .map_err(|_| ConnectionError::ChannelClosed)?;

        response_rx.await.map_err(|_| ConnectionError::ChannelClosed)?
    }

    /// Regulate a publish packet for store
    ///
    /// This method processes a PUBLISH packet to ensure it conforms to the connection's
    /// current state and regulations before storing it. This can include validation
    /// and transformation of the packet according to MQTT protocol rules.
    pub async fn regulate_for_store(
        &self,
        packet: mqtt::packet::v5_0::GenericPublish<PacketIdType>,
    ) -> Result<mqtt::packet::v5_0::GenericPublish<PacketIdType>, ConnectionError> {
        let tx_send = self.get_tx_send();
        let (response_tx, response_rx) = oneshot::channel();

        tx_send
            .send(RequestResponse::RegulateForStore {
                packet,
                response_tx,
            })
            .map_err(|_| ConnectionError::ChannelClosed)?;

        response_rx.await.map_err(|_| ConnectionError::ChannelClosed)?
    }

    /// Connect to the specified transport with default connection options
    pub async fn connect<T>(&self, transport: T) -> Result<(), ConnectionError>
    where
        T: crate::mqtt_ep::transport::TransportOps + Send + 'static,
    {
        self.connect_with_options(transport, GenericConnectionOption::<PacketIdType>::default())
            .await
    }

    /// Connect to the specified transport with specific connection options
    pub async fn connect_with_options<T>(
        &self,
        transport: T,
        options: GenericConnectionOption<PacketIdType>,
    ) -> Result<(), ConnectionError>
    where
        T: crate::mqtt_ep::transport::TransportOps + Send + 'static,
    {
        let (response_tx, response_rx) = oneshot::channel();

        if self
            .tx_send
            .send(RequestResponse::Connect {
                transport: Box::new(transport),
                options,
                response_tx,
            })
            .is_err()
        {
            return Err(ConnectionError::Transport(
                crate::mqtt_ep::transport::TransportError::NotConnected,
            ));
        }

        response_rx.await.map_err(|_| {
            ConnectionError::Transport(crate::mqtt_ep::transport::TransportError::NotConnected)
        })?
    }

    pub async fn accept<T>(&self, transport: T) -> Result<(), ConnectionError>
    where
        T: crate::mqtt_ep::transport::TransportOps + Send + 'static,
    {
        self.accept_with_options(transport, GenericConnectionOption::<PacketIdType>::default())
            .await
    }

    /// Connect to the specified transport with specific connection options
    pub async fn accept_with_options<T>(
        &self,
        transport: T,
        options: GenericConnectionOption<PacketIdType>,
    ) -> Result<(), ConnectionError>
    where
        T: crate::mqtt_ep::transport::TransportOps + Send + 'static,
    {
        let (response_tx, response_rx) = oneshot::channel();

        if self
            .tx_send
            .send(RequestResponse::Accept {
                transport: Box::new(transport),
                options,
                response_tx,
            })
            .is_err()
        {
            return Err(ConnectionError::Transport(
                crate::mqtt_ep::transport::TransportError::NotConnected,
            ));
        }

        response_rx.await.map_err(|_| {
            ConnectionError::Transport(crate::mqtt_ep::transport::TransportError::NotConnected)
        })?
    }

    /// Get the tx_send channel - always available in new architecture
    fn get_tx_send(&self) -> mpsc::UnboundedSender<RequestResponse<PacketIdType>> {
        self.tx_send.clone()
    }

    /// Apply connection options to the MQTT connection
    fn apply_connection_options(
        connection: &mut mqtt::GenericConnection<Role, PacketIdType>,
        options: GenericConnectionOption<PacketIdType>,
    ) {
        // Apply scalar settings (these are Copy, so we can access them after partial move)
        connection.set_pingreq_send_interval(*options.pingreq_send_interval_ms());
        connection.set_auto_pub_response(*options.set_auto_pub_response());
        connection.set_auto_ping_response(*options.set_auto_ping_response());
        connection.set_auto_map_topic_alias_send(*options.set_auto_map_topic_alias_send());
        connection.set_auto_replace_topic_alias_send(*options.set_auto_replace_topic_alias_send());
        connection.set_pingresp_recv_timeout(Some(*options.set_pingresp_recv_timeout_ms()));

        // Move large collections efficiently using the helper method
        let (restore_packets, restore_qos2_publish_handled) = options.into_restore_data();
        connection.restore_packets(restore_packets);
        connection.restore_qos2_publish_handled(restore_qos2_publish_handled);
    }

    /// Close the current connection
    pub async fn close(&self) -> Result<(), ConnectionError> {
        let (response_tx, response_rx) = oneshot::channel();

        if self
            .tx_send
            .send(RequestResponse::Close { response_tx })
            .is_err()
        {
            return Err(ConnectionError::ChannelClosed);
        }

        response_rx.await.map_err(|_| ConnectionError::ChannelClosed)?
    }

    /// Handle close request with proper queueing
    async fn handle_close_request(
        connection: &mut mqtt::GenericConnection<Role, PacketIdType>,
        transport: &mut Option<Box<dyn crate::mqtt_ep::transport::TransportOps + Send>>,
        pending_close_notifications: &mut Vec<oneshot::Sender<Result<(), ConnectionError>>>,
        pingreq_send_timer: &mut Option<tokio::task::JoinHandle<()>>,
        pingreq_recv_timer: &mut Option<tokio::task::JoinHandle<()>>,
        pingresp_recv_timer: &mut Option<tokio::task::JoinHandle<()>>,
        pending_packet_id_requests: &mut Vec<oneshot::Sender<Result<PacketIdType, ConnectionError>>>,
        response_tx: oneshot::Sender<Result<(), ConnectionError>>,
    ) {
        if pending_close_notifications.len() > 0 {
            // Close already in progress - add to queue
            pending_close_notifications.push(response_tx);
            return;
        }

        // Check if already disconnected
        if transport.is_none() {
            // Already disconnected - immediately notify
            let _ = response_tx.send(Ok(()));
            return;
        }

        // Start close process
        pending_close_notifications.push(response_tx);

        // Shutdown transport first
        let transport_ref = transport.as_mut().expect("Transport should be Some when close is requested - this is a bug");
        let _ = transport_ref.shutdown(Duration::from_secs(5)).await;

        // Notify connection about close and process events (including timer cancellation)
        let events = connection.notify_closed();
        let transport_ref = transport.as_mut().expect("Transport should still be Some after shutdown - this is a bug");
        let _ = Self::process_events(
            connection,
            transport_ref,
            pingreq_send_timer,
            pingreq_recv_timer,
            pingresp_recv_timer,
            &mpsc::unbounded_channel().0, // Dummy timer_tx since we're closing
            pending_packet_id_requests,
            events,
        ).await;
        // Note: We ignore MQTT errors during close as the connection is being terminated

        // Clear transport after processing events
        *transport = None;

        // Notify all pending close requests
        for tx in pending_close_notifications.drain(..) {
            let _ = tx.send(Ok(()));
        }
    }

    /// Event loop that handles transport I/O and MQTT protocol logic
    async fn event_loop(
        mut connection: mqtt::GenericConnection<Role, PacketIdType>,
        mut rx_send: mpsc::UnboundedReceiver<RequestResponse<PacketIdType>>,
    ) {
        let mut pingreq_send_timer: Option<tokio::task::JoinHandle<()>> = None;
        let mut pingreq_recv_timer: Option<tokio::task::JoinHandle<()>> = None;
        let mut pingresp_recv_timer: Option<tokio::task::JoinHandle<()>> = None;
        let (timer_tx, mut timer_rx) = mpsc::unbounded_channel::<TimerKind>();

        let mut pending_packet_id_requests: Vec<oneshot::Sender<Result<PacketIdType, ConnectionError>>> =
            Vec::new();
        let mut pending_close_notifications: Vec<oneshot::Sender<Result<(), ConnectionError>>> =
            Vec::new();
        let mut pending_recv_requests: Vec<(
            PacketFilter,
            oneshot::Sender<Result<mqtt::packet::GenericPacket<PacketIdType>, ConnectionError>>,
        )> = Vec::new();
        let mut transport: Option<Box<dyn crate::mqtt_ep::transport::TransportOps + Send>> = None;
        let mut read_buffer = vec![0u8; 4096];
        let mut buffer_size: usize = 0; // Actual data size in read_buffer
        let mut consumed_bytes: usize = 0; // Bytes consumed by connection.recv()

        loop {
            tokio::select! {
                // Handle requests from external API
                request = rx_send.recv() => {
                    match request {
                        Some(RequestResponse::Send { packet, response_tx }) => {
                            let events = connection.send(*packet);
                            if let Some(ref mut t) = transport {
                                match Self::process_events(&mut connection, t, &mut pingreq_send_timer, &mut pingreq_recv_timer, &mut pingresp_recv_timer, &timer_tx, &mut pending_packet_id_requests, events).await {
                                    Ok(()) => {
                                        let _ = response_tx.send(Ok(()));
                                    }
                                    Err(error) => {
                                        let _ = response_tx.send(Err(error));
                                    }
                                }
                            } else {
                                let _ = response_tx.send(Err(ConnectionError::NotConnected));
                            }
                        }
                        Some(RequestResponse::Recv { filter, response_tx }) => {
                            // Add to pending queue (non-blocking)
                            if transport.is_some() {
                                pending_recv_requests.push((filter, response_tx));
                            } else {
                                let _ = response_tx.send(Err(ConnectionError::NotConnected));
                            }
                        }
                        Some(RequestResponse::AcquirePacketId { response_tx }) => {
                            match connection.acquire_packet_id() {
                                Ok(packet_id) => {
                                    let _ = response_tx.send(Ok(packet_id));
                                }
                                Err(e) => {
                                    let _ = response_tx.send(Err(ConnectionError::Mqtt(e)));
                                }
                            }
                        }
                        Some(RequestResponse::AcquirePacketIdWhenAvailable { response_tx }) => {
                            match connection.acquire_packet_id() {
                                Ok(packet_id) => {
                                    let _ = response_tx.send(Ok(packet_id));
                                }
                                Err(_) => {
                                    pending_packet_id_requests.push(response_tx);
                                }
                            }
                        }
                        Some(RequestResponse::RegisterPacketId { packet_id, response_tx }) => {
                            let _ = connection.register_packet_id(packet_id);
                            let _ = response_tx.send(Ok(()));
                        }
                        Some(RequestResponse::ReleasePacketId { packet_id, response_tx }) => {
                            let events = connection.release_packet_id(packet_id);
                            if let Some(ref mut t) = transport {
                                match Self::process_events(&mut connection, t, &mut pingreq_send_timer, &mut pingreq_recv_timer, &mut pingresp_recv_timer, &timer_tx, &mut pending_packet_id_requests, events).await {
                                    Ok(()) => {
                                        let _ = response_tx.send(Ok(()));
                                    }
                                    Err(error) => {
                                        let _ = response_tx.send(Err(error));
                                    }
                                }
                            } else {
                                let _ = response_tx.send(Ok(())); // Release packet ID doesn't require transport
                            }
                        }
                        Some(RequestResponse::GetStoredPackets { response_tx }) => {
                            let packets = connection.get_stored_packets();
                            let _ = response_tx.send(Ok(packets));
                        }
                        Some(RequestResponse::RegulateForStore { packet, response_tx }) => {
                            match connection.regulate_for_store(packet.clone()) {
                                Ok(regulated_packet) => {
                                    let _ = response_tx.send(Ok(regulated_packet));
                                }
                                Err(_) => {
                                    let _ = response_tx.send(Ok(packet));
                                }
                            }
                        }
                        Some(RequestResponse::Connect { transport: new_transport, options, response_tx }) => {
                            let mut boxed_transport = new_transport;
                            match boxed_transport.connect().await {
                                Ok(()) => {
                                    Self::apply_connection_options(&mut connection, options);
                                    transport = Some(boxed_transport);
                                    let _ = response_tx.send(Ok(()));
                                }
                                Err(e) => {
                                    let _ = response_tx.send(Err(ConnectionError::Transport(e)));
                                }
                            }
                        }
                        Some(RequestResponse::Accept { transport: new_transport, options, response_tx }) => {
                            Self::apply_connection_options(&mut connection, options);
                            transport = Some(new_transport);
                            let _ = response_tx.send(Ok(()));
                        }
                        Some(RequestResponse::Close { response_tx }) => {
                            // Handle close request
                            Self::handle_close_request(
                                &mut connection,
                                &mut transport,
                                &mut pending_close_notifications,
                                &mut pingreq_send_timer,
                                &mut pingreq_recv_timer,
                                &mut pingresp_recv_timer,
                                &mut pending_packet_id_requests,
                                response_tx
                            ).await;
                        }
                        Some(RequestResponse::SetOfflinePublish { offline_publish, response_tx }) => {
                            connection.set_offline_publish(offline_publish);
                            let _ = response_tx.send(Ok(()));
                        }
                        Some(RequestResponse::GetQos2PublishHandled { response_tx }) => {
                            let pids = connection.get_qos2_publish_handled();
                            let _ = response_tx.send(Ok(pids));
                        }
                        Some(RequestResponse::GetReceiveMaximumVacancyForSend { response_tx }) => {
                            let vacancy = connection.get_receive_maximum_vacancy_for_send();
                            let _ = response_tx.send(Ok(vacancy));
                        }
                        Some(RequestResponse::GetProtocolVersion { response_tx }) => {
                            let version = connection.get_protocol_version();
                            let _ = response_tx.send(Ok(version));
                        }
                        Some(RequestResponse::IsPublishProcessing { packet_id, response_tx }) => {
                            let is_processing = connection.is_publish_processing(packet_id);
                            let _ = response_tx.send(Ok(is_processing));
                        }
                        None => break, // Channel closed
                    }
                }

                // Handle timer expiration
                timer_kind = timer_rx.recv() => {
                    if let Some(kind) = timer_kind {
                        match kind {
                            TimerKind::PingreqSend => pingreq_send_timer = None,
                            TimerKind::PingreqRecv => pingreq_recv_timer = None,
                            TimerKind::PingrespRecv => pingresp_recv_timer = None,
                        }
                        let events = connection.notify_timer_fired(kind);
                        if let Some(ref mut t) = transport {
                            let _ = Self::process_events(&mut connection, t, &mut pingreq_send_timer, &mut pingreq_recv_timer, &mut pingresp_recv_timer, &timer_tx, &mut pending_packet_id_requests, events).await;
                            // Note: We log MQTT errors from timer events but don't propagate them
                            // as there's no specific API call to respond to
                        }
                    }
                }

                // Handle transport receive (only when there are pending recv requests)
                recv_result = async {
                    if let Some(ref mut t) = transport {
                        if pending_recv_requests.is_empty() {
                            // No pending recv requests, don't try to receive
                            future::pending().await
                        } else {
                            // Check if we have unconsumed data in read_buffer
                            if consumed_bytes < buffer_size {
                                // Process remaining data in buffer
                                Some(Ok(0)) // Signal to process existing buffer
                            } else {
                                // Need new data from transport
                                Some(t.recv(&mut read_buffer).await)
                            }
                        }
                    } else {
                        // No transport available
                        future::pending().await
                    }
                } => {
                    if let Some(result) = recv_result {
                        match result {
                            Ok(n) if n > 0 => {
                                // New data received from transport
                                buffer_size = n;
                                consumed_bytes = 0;

                                // Process data in read_buffer
                                Self::process_read_buffer(
                                    &mut connection,
                                    &mut read_buffer,
                                    &mut buffer_size,
                                    &mut consumed_bytes,
                                    &mut pending_recv_requests,
                                    transport.as_mut().unwrap(),
                                    &mut pingreq_send_timer,
                                    &mut pingreq_recv_timer,
                                    &mut pingresp_recv_timer,
                                    &timer_tx,
                                    &mut pending_packet_id_requests,
                                ).await;
                            }
                            Ok(_) => {
                                // Process existing buffer data (n=0 case) or handle connection close
                                if consumed_bytes < buffer_size {
                                    // Process remaining data in buffer
                                    Self::process_read_buffer(
                                        &mut connection,
                                        &mut read_buffer,
                                        &mut buffer_size,
                                        &mut consumed_bytes,
                                        &mut pending_recv_requests,
                                        transport.as_mut().unwrap(),
                                        &mut pingreq_send_timer,
                                        &mut pingreq_recv_timer,
                                        &mut pingresp_recv_timer,
                                        &timer_tx,
                                        &mut pending_packet_id_requests,
                                    ).await;
                                } else {
                                    // Connection closed (n = 0) - notify all pending recv requests
                                    Self::notify_recv_connection_error(&mut pending_recv_requests);
                                    transport = None;
                                    buffer_size = 0;
                                    consumed_bytes = 0;
                                }
                            }
                            Err(_) => {
                                // Connection error - notify all pending recv requests
                                Self::notify_recv_connection_error(&mut pending_recv_requests);
                                transport = None;
                                buffer_size = 0;
                                consumed_bytes = 0;
                            }
                        }
                    }
                }

            }
        }

        // Cancel timers
        if let Some(handle) = pingreq_send_timer {
            handle.abort();
        }
        if let Some(handle) = pingreq_recv_timer {
            handle.abort();
        }
        if let Some(handle) = pingresp_recv_timer {
            handle.abort();
        }
    }

    /// Process all connection events first, then handle packet filtering for recv requests
    async fn process_received_packets_and_events<S>(
        connection: &mut mqtt::GenericConnection<Role, PacketIdType>,
        transport: &mut S,
        pingreq_send_timer: &mut Option<tokio::task::JoinHandle<()>>,
        pingreq_recv_timer: &mut Option<tokio::task::JoinHandle<()>>,
        pingresp_recv_timer: &mut Option<tokio::task::JoinHandle<()>>,
        timer_tx: &mpsc::UnboundedSender<TimerKind>,
        pending_packet_id_requests: &mut Vec<oneshot::Sender<Result<PacketIdType, ConnectionError>>>,
        pending_recv_requests: &mut Vec<(
            PacketFilter,
            oneshot::Sender<Result<mqtt::packet::GenericPacket<PacketIdType>, ConnectionError>>,
        )>,
        events: Vec<GenericEvent<PacketIdType>>,
    ) where
        S: crate::mqtt_ep::transport::TransportOps,
    {
        // First, process all connection events
        let _ = Self::process_events(
            connection,
            transport,
            pingreq_send_timer,
            pingreq_recv_timer,
            pingresp_recv_timer,
            timer_tx,
            pending_packet_id_requests,
            events.clone(),
        )
        .await;
        // Note: We log MQTT errors from received packets but don't propagate them
        // as they're not related to any specific API call but rather incoming data

        // Then, handle packet filtering for recv requests
        // Look for NotifyPacketReceived event (there should be 0 or 1)
        for event in &events {
            if let GenericEvent::NotifyPacketReceived(packet) = event {
                // Process pending recv requests in FIFO order (from front)
                if let Some((filter, _)) = pending_recv_requests.first() {
                    if filter.matches(packet) {
                        // Remove the first (oldest) request and send response
                        let (_, response_tx) = pending_recv_requests.remove(0);
                        let _ = response_tx.send(Ok(packet.clone()));
                        break; // Only satisfy one request per packet
                    }
                    // If packet doesn't match the first filter, we don't consume any request
                    // The packet will be "lost" and the select loop will automatically
                    // call t.recv() again since pending_recv_requests is not empty
                }
                break; // Only process the first NotifyPacketReceived event
            }
        }
    }

    /// Notify all pending recv requests about connection error
    fn notify_recv_connection_error(
        pending_recv_requests: &mut Vec<(
            PacketFilter,
            oneshot::Sender<Result<mqtt::packet::GenericPacket<PacketIdType>, ConnectionError>>,
        )>,
    ) {
        for (_, response_tx) in pending_recv_requests.drain(..) {
            let _ = response_tx.send(Err(ConnectionError::NotConnected));
        }
    }

    /// Process read buffer data - handles one packet per call as per endpoint.recv() semantics
    async fn process_read_buffer<S>(
        connection: &mut mqtt::GenericConnection<Role, PacketIdType>,
        read_buffer: &mut [u8],
        buffer_size: &mut usize,
        consumed_bytes: &mut usize,
        pending_recv_requests: &mut Vec<(
            PacketFilter,
            oneshot::Sender<Result<mqtt::packet::GenericPacket<PacketIdType>, ConnectionError>>,
        )>,
        transport: &mut S,
        pingreq_send_timer: &mut Option<tokio::task::JoinHandle<()>>,
        pingreq_recv_timer: &mut Option<tokio::task::JoinHandle<()>>,
        pingresp_recv_timer: &mut Option<tokio::task::JoinHandle<()>>,
        timer_tx: &mpsc::UnboundedSender<TimerKind>,
        pending_packet_id_requests: &mut Vec<oneshot::Sender<Result<PacketIdType, ConnectionError>>>,
    ) where
        S: crate::mqtt_ep::transport::TransportOps,
    {
        if *consumed_bytes >= *buffer_size {
            return; // No data to process
        }

        // Create cursor starting from unconsumed data
        let unconsumed_data = &read_buffer[*consumed_bytes..*buffer_size];
        let mut cursor = std::io::Cursor::new(unconsumed_data);
        let events = connection.recv(&mut cursor);
        let position_after = cursor.position();

        // Update consumed bytes based on what connection.recv() processed
        *consumed_bytes += position_after as usize;

        // Process all connection events first, then handle packet filtering
        Self::process_received_packets_and_events(
            connection,
            transport,
            pingreq_send_timer,
            pingreq_recv_timer,
            pingresp_recv_timer,
            timer_tx,
            pending_packet_id_requests,
            pending_recv_requests,
            events,
        ).await;
    }
}

pub type Endpoint<Role> = GenericEndpoint<Role, u16>;
