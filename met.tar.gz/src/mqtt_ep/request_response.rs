use std::collections::HashSet;

use crate::mqtt_ep::connection_option::GenericConnectionOption;
use crate::mqtt_ep::packet_filter::PacketFilter;
use mqtt_protocol_core::mqtt;
/**
 * MIT License
 *
 * Copyright (c) 2025 Takatoshi Kondo
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
use tokio::sync::oneshot;

pub(crate) enum RequestResponse<PacketIdType>
where
    PacketIdType: mqtt::types::IsPacketId + Send + Sync,
{
    Send {
        packet: Box<mqtt::packet::GenericPacket<PacketIdType>>,
        response_tx: oneshot::Sender<Result<(), ConnectionError>>,
    },
    Recv {
        filter: PacketFilter,
        response_tx: oneshot::Sender<Result<mqtt::packet::GenericPacket<PacketIdType>, ConnectionError>>,
    },
    AcquirePacketId {
        response_tx: oneshot::Sender<Result<PacketIdType, ConnectionError>>,
    },
    AcquirePacketIdWhenAvailable {
        response_tx: oneshot::Sender<Result<PacketIdType, ConnectionError>>,
    },
    RegisterPacketId {
        packet_id: PacketIdType,
        response_tx: oneshot::Sender<Result<(), ConnectionError>>,
    },
    ReleasePacketId {
        packet_id: PacketIdType,
        response_tx: oneshot::Sender<Result<(), ConnectionError>>,
    },
    Close {
        response_tx: oneshot::Sender<Result<(), ConnectionError>>,
    },
    Connect {
        transport: Box<dyn crate::mqtt_ep::transport::TransportOps + Send>,
        options: GenericConnectionOption<PacketIdType>,
        response_tx: oneshot::Sender<Result<(), ConnectionError>>,
    },
    Accept {
        transport: Box<dyn crate::mqtt_ep::transport::TransportOps + Send>,
        options: GenericConnectionOption<PacketIdType>,
        response_tx: oneshot::Sender<Result<(), ConnectionError>>,
    },
    GetStoredPackets {
        response_tx: oneshot::Sender<Result<Vec<mqtt::packet::GenericStorePacket<PacketIdType>>, ConnectionError>>,
    },
    SetOfflinePublish {
        offline_publish: bool,
        response_tx: oneshot::Sender<Result<(), ConnectionError>>,
    },
    GetQos2PublishHandled {
        response_tx: oneshot::Sender<Result<HashSet<PacketIdType>, ConnectionError>>,
    },
    GetReceiveMaximumVacancyForSend {
        response_tx: oneshot::Sender<Result<Option<u16>, ConnectionError>>,
    },
    GetProtocolVersion {
        response_tx: oneshot::Sender<Result<mqtt::Version, ConnectionError>>,
    },
    IsPublishProcessing {
        packet_id: PacketIdType,
        response_tx: oneshot::Sender<Result<bool, ConnectionError>>,
    },
    RegulateForStore {
        packet: mqtt::packet::v5_0::GenericPublish<PacketIdType>,
        response_tx: oneshot::Sender<Result<mqtt::packet::v5_0::GenericPublish<PacketIdType>, ConnectionError>>,
    },
}

/// Unified error type for all MQTT endpoint operations
///
/// This encompasses both MQTT protocol-level errors (from mqtt-protocol-core)
/// and I/O level errors that occur before MQTT protocol processing.
#[derive(Debug)]
pub enum ConnectionError {
    /// MQTT protocol-level error from mqtt-protocol-core
    Mqtt(mqtt::result_code::MqttError),
    /// I/O or transport-level error
    Transport(crate::mqtt_ep::transport::TransportError),
    /// Channel communication error (internal)
    ChannelClosed,
    /// Endpoint is not connected to any transport
    NotConnected,
    /// Connection is already established
    AlreadyConnected,
    /// Connection is already closed
    AlreadyDisconnected,
}

impl std::fmt::Display for ConnectionError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            ConnectionError::Mqtt(e) => write!(f, "MQTT protocol error: {:?}", e),
            ConnectionError::Transport(e) => write!(f, "Transport error: {}", e),
            ConnectionError::ChannelClosed => write!(f, "Internal channel closed"),
            ConnectionError::NotConnected => write!(f, "Not connected"),
            ConnectionError::AlreadyConnected => write!(f, "Already connected"),
            ConnectionError::AlreadyDisconnected => write!(f, "Already disconnected"),
        }
    }
}

impl std::error::Error for ConnectionError {}

impl From<mqtt::result_code::MqttError> for ConnectionError {
    fn from(e: mqtt::result_code::MqttError) -> Self {
        ConnectionError::Mqtt(e)
    }
}

impl From<crate::mqtt_ep::transport::TransportError> for ConnectionError {
    fn from(e: crate::mqtt_ep::transport::TransportError) -> Self {
        ConnectionError::Transport(e)
    }
}
