/**
 * MIT License
 *
 * Copyright (c) 2025 Takatoshi Kondo
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

use std::collections::HashSet;
use derive_builder::Builder;
use getset::{CopyGetters, Getters};
use mqtt_protocol_core::mqtt;

/// Connection options that can be set dynamically for each connection/reconnection
#[derive(Debug, Clone, Builder, Getters, CopyGetters)]
#[builder(derive(Debug), pattern = "owned", setter(into))]
pub struct GenericConnectionOption<PacketIdType>
where
    PacketIdType: mqtt::types::IsPacketId,
{
    #[builder(setter(into, strip_option))]
    #[getset(get = "pub")]
    pingreq_send_interval_ms: u64,
    #[builder(setter(into, strip_option))]
    #[getset(get = "pub")]
    set_auto_pub_response: bool,
    #[builder(setter(into, strip_option))]
    #[getset(get = "pub")]
    set_auto_ping_response: bool,
    #[builder(setter(into, strip_option))]
    #[getset(get = "pub")]
    set_auto_map_topic_alias_send: bool,
    #[builder(setter(into, strip_option))]
    #[getset(get = "pub")]
    set_auto_replace_topic_alias_send: bool,
    #[builder(setter(into, strip_option))]
    #[getset(get = "pub")]
    set_pingresp_recv_timeout_ms: u64,
    #[builder(setter(into, strip_option))]
    #[getset(get = "pub")]
    restore_packets: Vec<mqtt::packet::GenericStorePacket<PacketIdType>>,
    #[builder(setter(into, strip_option))]
    #[getset(get = "pub")]
    restore_qos2_publish_handled_pids: HashSet<PacketIdType>,
}

pub type ConnectionOption = GenericConnectionOption<u16>;

impl<PacketIdType> Default for GenericConnectionOption<PacketIdType>
where
    PacketIdType: mqtt::types::IsPacketId,
{
    fn default() -> Self {
        Self::builder()
            .pingreq_send_interval_ms(0u64)
            .set_auto_pub_response(true)
            .set_auto_ping_response(true)
            .set_auto_map_topic_alias_send(false)
            .set_auto_replace_topic_alias_send(false)
            .set_pingresp_recv_timeout_ms(0u64)
            .restore_packets(Vec::new())
            .restore_qos2_publish_handled_pids(HashSet::new())
            .build()
            .expect("Default GenericConnectionOption should be valid")
    }
}

impl<PacketIdType> GenericConnectionOption<PacketIdType>
where
    PacketIdType: mqtt::types::IsPacketId,
{
    pub fn builder() -> GenericConnectionOptionBuilder<PacketIdType> {
        GenericConnectionOptionBuilder::<PacketIdType>::default()
    }

    /// Move both restore_packets and restore_qos2_publish_handled_pids out of the struct
    /// Returns (restore_packets, restore_qos2_publish_handled_pids)
    pub fn into_restore_data(self) -> (Vec<mqtt::packet::GenericStorePacket<PacketIdType>>, HashSet<PacketIdType>) {
        (self.restore_packets, self.restore_qos2_publish_handled_pids)
    }
}
