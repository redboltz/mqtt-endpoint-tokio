// Test for the subscription store module

use std::collections::{HashMap, HashSet};
use std::sync::Arc;
use tokio::sync::RwLock;

// Mock tracing for tests
macro_rules! trace {
    ($($arg:tt)*) => {};
}

/// Simple error type for subscription operations
#[derive(Debug, Clone)]
pub enum SubscriptionError {
    InvalidTopicFilter,
}

impl std::fmt::Display for SubscriptionError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            SubscriptionError::InvalidTopicFilter => write!(f, "Invalid topic filter"),
        }
    }
}

impl std::error::Error for SubscriptionError {}

pub type ClientId = String;

/// Trie node containing subscription information
#[derive(Debug, Clone, Default)]
struct TrieNode {
    /// Clients subscribed to this exact path
    exact_subscribers: HashSet<ClientId>,
    /// Clients subscribed with single-level wildcard at this position
    single_wildcard_subscribers: HashSet<ClientId>,
    /// Clients subscribed with multi-level wildcard from this position
    multi_wildcard_subscribers: HashSet<ClientId>,
    /// Child nodes for each segment
    children: HashMap<String, TrieNode>,
    /// Special child for single-level wildcard (+)
    wildcard_child: Option<Box<TrieNode>>,
}

/// Subscription store using Trie-based structure for efficient wildcard matching
#[derive(Debug, Clone)]
pub struct SubscriptionStore {
    /// Root of the trie structure
    root: Arc<RwLock<TrieNode>>,
}

impl SubscriptionStore {
    /// Create a new subscription store
    pub fn new() -> Self {
        Self {
            root: Arc::new(RwLock::new(TrieNode::default())),
        }
    }

    /// Add a subscription for a client to a topic filter
    pub async fn subscribe(&self, client_id: ClientId, topic_filter: &str) -> Result<(), SubscriptionError> {
        Self::validate_topic_filter(topic_filter)?;

        let mut root = self.root.write().await;
        let segments: Vec<&str> = topic_filter.split('/').collect();

        Self::insert_subscription(&mut root, &segments, client_id.clone(), 0);

        trace!("Subscribed client '{}' to topic filter '{}'", client_id, topic_filter);
        Ok(())
    }

    /// Recursively insert subscription into trie
    fn insert_subscription(node: &mut TrieNode, segments: &[&str], client_id: ClientId, depth: usize) {
        if depth >= segments.len() {
            // End of path - add to exact subscribers
            node.exact_subscribers.insert(client_id);
            return;
        }

        let segment = segments[depth];

        match segment {
            "#" => {
                // Multi-level wildcard - matches everything from this point
                node.multi_wildcard_subscribers.insert(client_id);
            }
            "+" => {
                // Single-level wildcard
                if node.wildcard_child.is_none() {
                    node.wildcard_child = Some(Box::new(TrieNode::default()));
                }
                if let Some(ref mut wildcard_child) = node.wildcard_child {
                    if depth + 1 >= segments.len() {
                        // This is the last segment
                        wildcard_child.single_wildcard_subscribers.insert(client_id);
                    } else {
                        Self::insert_subscription(wildcard_child, segments, client_id, depth + 1);
                    }
                }
            }
            _ => {
                // Exact segment
                let child = node.children.entry(segment.to_string()).or_insert_with(TrieNode::default);
                Self::insert_subscription(child, segments, client_id, depth + 1);
            }
        }
    }

    /// Remove a subscription for a client from a topic filter
    pub async fn unsubscribe(&self, client_id: &ClientId, topic_filter: &str) -> Result<bool, SubscriptionError> {
        Self::validate_topic_filter(topic_filter)?;

        let mut root = self.root.write().await;
        let segments: Vec<&str> = topic_filter.split('/').collect();

        let removed = Self::remove_subscription(&mut root, &segments, client_id, 0);
        Ok(removed)
    }

    /// Recursively remove subscription from trie
    fn remove_subscription(node: &mut TrieNode, segments: &[&str], client_id: &ClientId, depth: usize) -> bool {
        if depth >= segments.len() {
            return node.exact_subscribers.remove(client_id);
        }

        let segment = segments[depth];

        match segment {
            "#" => {
                node.multi_wildcard_subscribers.remove(client_id)
            }
            "+" => {
                if let Some(ref mut wildcard_child) = node.wildcard_child {
                    if depth + 1 >= segments.len() {
                        wildcard_child.single_wildcard_subscribers.remove(client_id)
                    } else {
                        Self::remove_subscription(wildcard_child, segments, client_id, depth + 1)
                    }
                } else {
                    false
                }
            }
            _ => {
                if let Some(child) = node.children.get_mut(segment) {
                    Self::remove_subscription(child, segments, client_id, depth + 1)
                } else {
                    false
                }
            }
        }
    }

    /// Remove all subscriptions for a client
    pub async fn unsubscribe_all(&self, client_id: &ClientId) {
        let mut root = self.root.write().await;
        Self::remove_all_subscriptions(&mut root, client_id);
    }

    /// Recursively remove all subscriptions for a client
    fn remove_all_subscriptions(node: &mut TrieNode, client_id: &ClientId) {
        node.exact_subscribers.remove(client_id);
        node.single_wildcard_subscribers.remove(client_id);
        node.multi_wildcard_subscribers.remove(client_id);

        // Recursively clean children
        for child in node.children.values_mut() {
            Self::remove_all_subscriptions(child, client_id);
        }

        if let Some(ref mut wildcard_child) = node.wildcard_child {
            Self::remove_all_subscriptions(wildcard_child, client_id);
        }
    }

    /// Find all subscribers for a given published topic
    pub async fn find_subscribers(&self, topic: &str) -> Vec<ClientId> {
        let root = self.root.read().await;
        let mut all_subscribers = HashSet::new();
        let segments: Vec<&str> = topic.split('/').collect();

        trace!("Looking for subscribers to topic '{}'", topic);

        Self::collect_subscribers(&root, &segments, 0, &mut all_subscribers);

        let result: Vec<ClientId> = all_subscribers.into_iter().collect();
        trace!("Final subscriber list for '{}': {:?}", topic, result);
        result
    }

    /// Recursively collect all matching subscribers
    fn collect_subscribers(
        node: &TrieNode,
        topic_segments: &[&str],
        depth: usize,
        subscribers: &mut HashSet<ClientId>,
    ) {
        // Multi-level wildcards match everything from this point
        subscribers.extend(node.multi_wildcard_subscribers.iter().cloned());

        if depth >= topic_segments.len() {
            // End of topic path - collect exact subscribers
            subscribers.extend(node.exact_subscribers.iter().cloned());
            return;
        }

        let current_segment = topic_segments[depth];

        // 1. Check exact match
        if let Some(child) = node.children.get(current_segment) {
            Self::collect_subscribers(child, topic_segments, depth + 1, subscribers);
        }

        // 2. Check single-level wildcard match
        if let Some(ref wildcard_child) = node.wildcard_child {
            if depth + 1 >= topic_segments.len() {
                // This is the last segment - collect single wildcard subscribers
                subscribers.extend(wildcard_child.single_wildcard_subscribers.iter().cloned());
            } else {
                // Continue to next level
                Self::collect_subscribers(wildcard_child, topic_segments, depth + 1, subscribers);
            }
        }
    }

    /// Check if a client is subscribed to a specific topic filter
    pub async fn is_subscribed(&self, client_id: &ClientId, topic_filter: &str) -> bool {
        let root = self.root.read().await;
        let segments: Vec<&str> = topic_filter.split('/').collect();

        Self::check_subscription(&root, &segments, client_id, 0)
    }

    /// Recursively check if a subscription exists
    fn check_subscription(node: &TrieNode, segments: &[&str], client_id: &ClientId, depth: usize) -> bool {
        if depth >= segments.len() {
            return node.exact_subscribers.contains(client_id);
        }

        let segment = segments[depth];

        match segment {
            "#" => {
                node.multi_wildcard_subscribers.contains(client_id)
            }
            "+" => {
                if let Some(ref wildcard_child) = node.wildcard_child {
                    if depth + 1 >= segments.len() {
                        wildcard_child.single_wildcard_subscribers.contains(client_id)
                    } else {
                        Self::check_subscription(wildcard_child, segments, client_id, depth + 1)
                    }
                } else {
                    false
                }
            }
            _ => {
                if let Some(child) = node.children.get(segment) {
                    Self::check_subscription(child, segments, client_id, depth + 1)
                } else {
                    false
                }
            }
        }
    }

    /// Get all topic filters for a client
    pub async fn get_client_subscriptions(&self, client_id: &ClientId) -> Vec<String> {
        let root = self.root.read().await;
        let mut subscriptions = Vec::new();
        let mut current_path = Vec::new();

        Self::collect_client_subscriptions(&root, client_id, &mut current_path, &mut subscriptions);

        subscriptions
    }

    /// Recursively collect all subscriptions for a client
    fn collect_client_subscriptions(
        node: &TrieNode,
        client_id: &ClientId,
        current_path: &mut Vec<String>,
        subscriptions: &mut Vec<String>,
    ) {
        // Check exact subscription at this level
        if node.exact_subscribers.contains(client_id) {
            subscriptions.push(current_path.join("/"));
        }

        // Check multi-level wildcard subscription
        if node.multi_wildcard_subscribers.contains(client_id) {
            let mut path = current_path.clone();
            path.push("#".to_string());
            subscriptions.push(path.join("/"));
        }

        // Check single-level wildcard subscription
        if let Some(ref wildcard_child) = node.wildcard_child {
            if wildcard_child.single_wildcard_subscribers.contains(client_id) {
                let mut path = current_path.clone();
                path.push("+".to_string());
                subscriptions.push(path.join("/"));
            }

            // Recurse into wildcard child
            current_path.push("+".to_string());
            Self::collect_client_subscriptions(wildcard_child, client_id, current_path, subscriptions);
            current_path.pop();
        }

        // Recurse into exact children
        for (segment, child) in &node.children {
            current_path.push(segment.clone());
            Self::collect_client_subscriptions(child, client_id, current_path, subscriptions);
            current_path.pop();
        }
    }

    /// Validate MQTT topic filter according to spec
    fn validate_topic_filter(topic_filter: &str) -> Result<(), SubscriptionError> {
        if topic_filter.is_empty() {
            return Err(SubscriptionError::InvalidTopicFilter);
        }

        let segments = topic_filter.split('/');
        let mut has_multi_wildcard = false;

        for (i, segment) in segments.enumerate() {
            // Check for multi-level wildcard
            if segment == "#" {
                if has_multi_wildcard {
                    return Err(SubscriptionError::InvalidTopicFilter);
                }
                has_multi_wildcard = true;

                // # must be the last segment
                if i != topic_filter.split('/').count() - 1 {
                    return Err(SubscriptionError::InvalidTopicFilter);
                }
            }
            // Check for single-level wildcard
            else if segment == "+" {
                // + is valid as a complete segment
            }
            // Check for invalid wildcard usage
            else if segment.contains('+') || segment.contains('#') {
                return Err(SubscriptionError::InvalidTopicFilter);
            }
        }

        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[tokio::test]
    async fn test_trie_exact_subscription() {
        let store = SubscriptionStore::new();

        // Subscribe client1 to exact topic
        store.subscribe("client1".to_string(), "sensor/temperature").await.unwrap();

        // Test exact match
        let subscribers = store.find_subscribers("sensor/temperature").await;
        assert_eq!(subscribers.len(), 1);
        assert!(subscribers.contains(&"client1".to_string()));

        // Test no match
        let subscribers = store.find_subscribers("sensor/humidity").await;
        assert_eq!(subscribers.len(), 0);
    }

    #[tokio::test]
    async fn test_trie_single_wildcard() {
        let store = SubscriptionStore::new();

        // Subscribe to single-level wildcard
        store.subscribe("client1".to_string(), "sensor/+").await.unwrap();

        // Test matches
        let subscribers = store.find_subscribers("sensor/temperature").await;
        assert_eq!(subscribers.len(), 1);

        let subscribers = store.find_subscribers("sensor/humidity").await;
        assert_eq!(subscribers.len(), 1);

        // Test no match (too deep)
        let subscribers = store.find_subscribers("sensor/room1/temperature").await;
        assert_eq!(subscribers.len(), 0);

        // Test no match (wrong prefix)
        let subscribers = store.find_subscribers("actuator/motor").await;
        assert_eq!(subscribers.len(), 0);
    }

    #[tokio::test]
    async fn test_trie_multi_wildcard() {
        let store = SubscriptionStore::new();

        // Subscribe to multi-level wildcard
        store.subscribe("client1".to_string(), "sensor/#").await.unwrap();

        // Test matches at different levels
        let subscribers = store.find_subscribers("sensor/temperature").await;
        assert_eq!(subscribers.len(), 1);

        let subscribers = store.find_subscribers("sensor/room1/temperature").await;
        assert_eq!(subscribers.len(), 1);

        let subscribers = store.find_subscribers("sensor/building/floor1/room5/temp").await;
        assert_eq!(subscribers.len(), 1);

        // Test no match
        let subscribers = store.find_subscribers("actuator/motor").await;
        assert_eq!(subscribers.len(), 0);
    }

    #[tokio::test]
    async fn test_trie_complex_matching() {
        let store = SubscriptionStore::new();

        // Multiple subscription types
        store.subscribe("exact_client".to_string(), "sensor/room1/temperature").await.unwrap();
        store.subscribe("single_client".to_string(), "sensor/+/temperature").await.unwrap();
        store.subscribe("multi_client".to_string(), "sensor/#").await.unwrap();
        store.subscribe("root_multi".to_string(), "#").await.unwrap();

        // Test topic that matches all
        let mut subscribers = store.find_subscribers("sensor/room1/temperature").await;
        subscribers.sort();
        assert_eq!(subscribers.len(), 4);
        assert!(subscribers.contains(&"exact_client".to_string()));
        assert!(subscribers.contains(&"single_client".to_string()));
        assert!(subscribers.contains(&"multi_client".to_string()));
        assert!(subscribers.contains(&"root_multi".to_string()));

        // Test topic that matches some
        let mut subscribers = store.find_subscribers("sensor/room2/temperature").await;
        subscribers.sort();
        assert_eq!(subscribers.len(), 3);
        assert!(subscribers.contains(&"single_client".to_string()));
        assert!(subscribers.contains(&"multi_client".to_string()));
        assert!(subscribers.contains(&"root_multi".to_string()));
    }

    #[tokio::test]
    async fn test_trie_performance_scenario() {
        let store = SubscriptionStore::new();

        // Add many subscriptions to test performance
        for i in 0..100 {
            store.subscribe(format!("exact_{}", i), &format!("device/{}/status", i)).await.unwrap();
        }

        for i in 0..50 {
            store.subscribe(format!("single_{}", i), &format!("device/+/sensor{}", i)).await.unwrap();
        }

        for i in 0..20 {
            store.subscribe(format!("multi_{}", i), &format!("device/group{}/#", i)).await.unwrap();
        }

        // Test lookup performance
        let start = std::time::Instant::now();

        for i in 0..100 {
            let topic = format!("device/{}/status", i);
            let subscribers = store.find_subscribers(&topic).await;
            assert_eq!(subscribers.len(), 1); // Only exact match
        }

        let duration = start.elapsed();
        println!("100 exact lookups took: {:?}", duration);
        assert!(duration.as_millis() < 100); // Should be very fast
    }

    #[tokio::test]
    async fn test_trie_unsubscribe() {
        let store = SubscriptionStore::new();

        // Subscribe multiple clients
        store.subscribe("client1".to_string(), "sensor/+").await.unwrap();
        store.subscribe("client2".to_string(), "sensor/#").await.unwrap();
        store.subscribe("client3".to_string(), "sensor/temperature").await.unwrap();

        // Verify all are present
        let subscribers = store.find_subscribers("sensor/temperature").await;
        assert_eq!(subscribers.len(), 3);

        // Unsubscribe one
        assert!(store.unsubscribe(&"client1".to_string(), "sensor/+").await.unwrap());

        // Verify removal
        let subscribers = store.find_subscribers("sensor/temperature").await;
        assert_eq!(subscribers.len(), 2);
        assert!(!subscribers.contains(&"client1".to_string()));

        // Try to unsubscribe again - should return false
        assert!(!store.unsubscribe(&"client1".to_string(), "sensor/+").await.unwrap());
    }

    #[tokio::test]
    async fn test_trie_is_subscribed() {
        let store = SubscriptionStore::new();

        store.subscribe("client1".to_string(), "sensor/+").await.unwrap();
        store.subscribe("client1".to_string(), "actuator/#").await.unwrap();

        // Test positive cases
        assert!(store.is_subscribed(&"client1".to_string(), "sensor/+").await);
        assert!(store.is_subscribed(&"client1".to_string(), "actuator/#").await);

        // Test negative cases
        assert!(!store.is_subscribed(&"client1".to_string(), "sensor/temperature").await);
        assert!(!store.is_subscribed(&"client2".to_string(), "sensor/+").await);
    }
}
